import os
import cv2

from hf_mnist import predict_numbers_in_rois

os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'


def thresholding(image):
    image = cv2.imread(image)
    original = image.copy()
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    canny = cv2.Canny(blurred, 50, 200, 255)
    # cv2.imshow("Output", canny)
    # cv2.waitKey(0)

    ROI_number = 0
    ROIs = {}  # Dictionary to store ROIs and their coordinates
    roi_dir = "img_roi"
    cnts = cv2.findContours(canny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]

    for c in cnts:
        x, y, w, h = cv2.boundingRect(c)
        roi_area = w * h

        if 200 < roi_area < 1500:
            ROI = original[y:y + h, x:x + w]
            ROIs[ROI_number] = ((x, y, w, h), ROI)  # Store ROI coordinates and image array

            roi_filename = os.path.join(roi_dir, f"roi_{ROI_number}.png")
            cv2.imwrite(roi_filename, ROI)

        ROI_number += 1

    predictions = predict_numbers_in_rois(ROIs)

    result = ', '.join([f"{number} [{confidence:.2f},{y}]" for y, number, confidence in predictions])
    print(result)
    return ROIs
