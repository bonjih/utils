import cv2
import os

from RoiMultiClass import ComposeROI
import global_params_variables
from process_truck import thresholding
from stream_video import VideoStreamer


def run():
    params = global_params_variables.ParamsDict()
    configs = ComposeROI(params.get_all_items())
    video_path = configs.video_file
    offset = params.get_value('offset')  # start the video at ts

    streamer = VideoStreamer.stream_helper(video_path, configs, offset)

    for frame, cam_name in streamer:
        cv2.imshow(cam_name, frame)
        if cv2.waitKey(1) == ord('q'):
            break


def main():
    run()
    thresholding(r"C:\Users\ben.hamilton\PycharmProjects\weightbridge\saved_frames\frame_720.jpg")


if __name__ == "__main__":
    main()

